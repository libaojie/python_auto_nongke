#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Comment    : 装饰器
@Time       : 2020/02/06 16:26
@Author     : libaojie
@File       : test_rely.py
@Software   : PyCharm
"""
from dmat_common.log_tool import LogTool


def test_log():
    """
    测试log
    :return:
    """
    LogTool.info("info")


