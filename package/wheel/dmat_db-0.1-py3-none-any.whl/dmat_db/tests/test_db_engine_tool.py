from dmat_db.db_engine_tool import DBEngineTool


def test():
    db = 1
    page_numb = 5
    page_size = 6
    page_code = 'code'
    page_key  = 'key'
    dict_tbl_name = 'dmatmr.mr_dict'
    DBEngineTool.init(db, page_numb, page_size, page_code, page_key, dict_tbl_name)
    DBEngineTool.find_by_sql("qs", 4, 5)


test()