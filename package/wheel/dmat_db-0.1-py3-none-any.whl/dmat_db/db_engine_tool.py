#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Comment    : 数据库Engine操作
@Time       : 2020/02/06 20:05
@Author     : libaojie
@File       : db_base_tool.py
@Software   : PyCharm
"""
from dmat_common.log_tool import LogTool

from dmat_db.db_base_tool import DBBaseTool
from dmat_db.entity.ret_run_sql import RetRunSql
from dmat_db.sql_tool import SQLTool


class DBEngineTool(DBBaseTool):
    """
    数据库Engine操作
    """

    def __init__(self):
        super().__init__()
        pass

    @classmethod
    def _get_engine(cls):
        # return create_engine(ConfigTool.get_str('flask', 'SQLALCHEMY_DATABASE_URI'))
        return cls._get_db().engine

    @classmethod
    def run_sql(cls, sql):
        """
        执行sql
        :param sql:
        :return: RetRunSql
        """
        if not super()._is_init():
            return None

        sql = sql.replace('\n', '')
        retRunSql = RetRunSql()
        db_engine = cls._get_engine()
        conn = db_engine.raw_connection()
        try:
            LogTool.info('执行sql：{0}'.format(sql))
            cursor = conn.cursor()  # 打开操作游标
            ret = cursor.execute(sql)  # 执行数据插入操作
            try:
                retRunSql.col_list = [r[0] for r in ret.description]
                retRunSql.val_list = ret.fetchall()
                retRunSql.is_success = True
            except Exception as e:
                pass
            conn.commit()
            LogTool.info(f"执行sql结束")
            cursor.close()
            return retRunSql
        except Exception as e:
            conn.rollback()  # 异常则回滚
            LogTool.error("执行数据库报错，报错信息：{0}\n报错语句：{1}".format(e, sql))
            return retRunSql
        finally:
            conn.close()

    @classmethod
    def executemany(cls, sql, val):
        """
        批量插入
        :param sql: string
        :param val: list 二维数组
        :return: Bool 是否插入成功
        """
        if not super()._is_init():
            return None

        sql = sql.replace('\n', '')
        db_engine = cls._get_engine()
        conn = db_engine.raw_connection()
        cursor = conn.cursor()  # 打开操作游标
        try:
            cursor.executemany(sql, val)  # 执行数据插入操作
            conn.commit()  # 正常则提交
            cursor.close()
            return True
        except Exception as e:
            conn.rollback()  # 异常则回滚
            LogTool.error("插入数据库报错：{0}".format(e))
            return False
        finally:
            conn.close()

    @classmethod
    def insert_rows(cls, ptbl_name, pcols, prow_vals):
        """
        插入数据记录集，支持多条记录按List插入
        :param ptbl_name: String 数据库表名
        :param pcols: List 数据列名组成的列表，一个元素代表一列
        :param prow_vals: List 值列表，一个元素代表一行，一行内的元素个数要与SQL中的数量对应
        :return: Bool 是否插入成功
        """
        if len(pcols) == 0 or len(prow_vals) == 0:
            LogTool.error("数据参数错误：pcols【长度为{}】或prow_vals【长度为{}】异常".format(len(pcols), len(prow_vals)))
            return False

        _insert_sql = SQLTool.get_tmpl_sql(ptbl_name, pcols)

        return cls.executemany(_insert_sql, prow_vals)