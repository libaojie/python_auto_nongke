from dmat_common.log_tool import LogTool

LogTool.init("./data")
LogTool.info("123")

