import os
import sys

from dmat_common.config_tool import ConfigTool
from dmat_common.log_tool1 import LogTool
from dmat_common.time_tool import TimeTool

try:
    mainroot = os.path.dirname(os.path.abspath(__file__))
except NameError:
    mainroot = os.path.dirname(os.path.abspath(sys.argv[0]))

ConfigTool.set_path(mainroot)
LogTool.init(mainroot)

LogTool.info(f"{TimeTool.get_currer_time()}")