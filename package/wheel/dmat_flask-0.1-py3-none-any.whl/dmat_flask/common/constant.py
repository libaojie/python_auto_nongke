

# 鉴权
APPID = "appid"
USERID = "userid"
USERNAME = "username"
LOGINNAME = "loginname"
SYSLOGID = "sysLogId"
MSG = "msg"
Dmat_Time_Begin = "dmattimebegin"


# header
Authorization = "Authorization"
Application = "Application"
AuthUserName = "AuthUserName"
AuthPassword = "AuthPassword"
UserAgent = "User-Agent"
ApplicationCode = "ApplicationCode"