#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Comment    : 
@Time       : 2019/4/9 17:36
@Author     : libaojie
@File       : orm_tool.py
@Software   : PyCharm
"""
from dmat_common.log_tool import LogTool
from dmat_db.db_engine_tool import DBEngineTool
from dmat_db.entity.ret_find import RetFind
from sqlalchemy import text

from dmat_flask.enum.del_flag import DelFlag

"""
class OrmRetData(object):

    items = []  # 列表
    total = None  # 数据量
    page = None  # 当前页
    per_page = None  # 每页多少"""


class OrmTool(object):

    @staticmethod
    def find_by_query(model, page=None, per_page=None, del_flag=DelFlag.view.value, precise_dict=None,
                      fuzzy_dict=None, other_str=None):
        """

        :param model:
        :param page:
        :param per_page:
        :param del_flag:
        :param precise_dict:
        :param fuzzy_dict:
        :param other_str:
        :return: RetFind
        """
        query = model.query
        # 排序
        query = query.order_by(model.create_time.desc())
        # 数据状态
        if del_flag != DelFlag.all.value:
            query = query.filter(text(f"del_flag = '{del_flag}'"))
        #print(str(query))
        # 精准查询字段
        if precise_dict and isinstance(precise_dict, dict) and len(precise_dict) > 0:
            for key, value in precise_dict.items():
                if not hasattr(model, key):
                    LogTool.error(f"【{model.__tablename__}】表找不到{key}字段")
                    continue
                if value:
                    query = query.filter(text(f"{key} = '{value}'"))

        # 模糊查询
        if fuzzy_dict and isinstance(fuzzy_dict, dict) and len(fuzzy_dict) > 0:
            for key, value in fuzzy_dict.items():
                if not hasattr(model, key):
                    LogTool.error(f"【{model.__tablename__}】表找不到{key}字段")
                    continue
                if value:
                    query = query.filter(text(f"regexp_like({key}, '{value}', 'i') "))

        retFind = RetFind()
        #ormRetData = OrmRetData()
        if page:
            page, per_page = DBEngineTool.get_page_val(page, per_page)
            query = query.paginate(page, per_page, error_out=False)
            retFind.data = query.items
            retFind.page_numb = page
            retFind.page_size = per_page
            retFind.page_total = query.pages
            retFind.total = query.total

            #ormRetData.items = query.items
            #ormRetData.total = query.total
            #ormRetData.page = page
            #ormRetData.per_page = per_page
        else:
            retFind.data = query.all()
            retFind.page_numb = None
            retFind.page_size = None
            retFind.page_total = None
            retFind.total = None
            #ormRetData.items = query.all()
            #ormRetData.total = None
            #ormRetData.page = None
            #ormRetData.per_page = None
        return retFind
